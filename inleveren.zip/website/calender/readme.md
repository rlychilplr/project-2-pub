# ICS

waarschijnlijk buiten de scope van dit project maar wal grappig als ik tijd heb.

een iCalender uitnodiging voor de open dag en de info dag van Techniek College Rotterdam.
